<?php

declare(strict_types=1);

namespace Preset\Domain\Exceptions;

use Exception;

class LockedPresetException extends Exception
{
}
