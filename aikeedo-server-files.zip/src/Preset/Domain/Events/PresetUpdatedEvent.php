<?php

declare(strict_types=1);

namespace Preset\Domain\Events;

class PresetUpdatedEvent extends AbstractPresetEvent
{
}
