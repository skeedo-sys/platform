<?php

declare(strict_types=1);

namespace Shared\Infrastructure\Config;

use Adbar\Dot;

class Config extends Dot
{
}
