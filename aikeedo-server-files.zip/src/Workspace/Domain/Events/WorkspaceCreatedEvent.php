<?php

declare(strict_types=1);

namespace Workspace\Domain\Events;

class WorkspaceCreatedEvent extends AbstractWorkspaceEvent
{
}
