<?php

declare(strict_types=1);

namespace Option\Domain\Events;

class OptionCreatedEvent extends AbstractOptionEvent
{
}
