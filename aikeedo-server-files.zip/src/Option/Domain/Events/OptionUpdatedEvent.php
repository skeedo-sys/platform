<?php

declare(strict_types=1);

namespace Option\Domain\Events;

class OptionUpdatedEvent extends AbstractOptionEvent
{
}
