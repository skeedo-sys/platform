<?php

declare(strict_types=1);

namespace Category\Domain\Events;

class CategoryCreatedEvent extends AbstractCategoryEvent
{
}
