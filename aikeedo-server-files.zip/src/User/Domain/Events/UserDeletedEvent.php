<?php

declare(strict_types=1);

namespace User\Domain\Events;

class UserDeletedEvent extends AbstractUserEvent
{
}
