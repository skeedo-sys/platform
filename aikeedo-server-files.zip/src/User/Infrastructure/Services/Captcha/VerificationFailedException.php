<?php

declare(strict_types=1);

namespace User\Infrastructure\Services\Captcha;

use Exception;

class VerificationFailedException extends Exception
{
}
