<?php

namespace Plugin\Domain\Exceptions;

use Exception;

class PluginInterfaceNotImplementedException extends Exception
{
}
