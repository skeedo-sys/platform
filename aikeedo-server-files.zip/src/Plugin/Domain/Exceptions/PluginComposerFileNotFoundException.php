<?php

declare(strict_types=1);

namespace Plugin\Domain\Exceptions;

use Exception;

class PluginComposerFileNotFoundException extends Exception
{
}
