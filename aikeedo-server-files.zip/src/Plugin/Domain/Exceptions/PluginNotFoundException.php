<?php

namespace Plugin\Domain\Exceptions;

use Exception;

class PluginNotFoundException extends Exception
{
}
