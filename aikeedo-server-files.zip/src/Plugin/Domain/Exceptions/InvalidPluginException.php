<?php

namespace Plugin\Domain\Exceptions;

use Exception;

class InvalidPluginException extends Exception
{
}
