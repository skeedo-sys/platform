'use strict';

import { Api } from "../api";

let api = new Api();
api.base = '/api/auth';

export default api;