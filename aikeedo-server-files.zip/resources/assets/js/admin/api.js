'use strict';

import { Api } from "../api";

let api = new Api();
api.base = '/admin/api';
export default api;